presets: [
  [
    "@vue/app",
    {
      useBuiltIns: "entry",
    },
  ],
];
