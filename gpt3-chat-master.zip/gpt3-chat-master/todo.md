## todo

Wishlist

> contextual information for agent
> primer/samples to "switch" personas from a single thread
> adjust temperature conversationally/commands

Boring

> export/import persona config (backend)

Cool

> streaming
> documents
> rich components & api responses
